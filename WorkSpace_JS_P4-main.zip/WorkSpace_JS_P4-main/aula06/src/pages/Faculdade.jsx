import React from 'react'

const Faculdade = () => {
  return (
    <div>Faculdade</div>
  )
}

export default Faculdade