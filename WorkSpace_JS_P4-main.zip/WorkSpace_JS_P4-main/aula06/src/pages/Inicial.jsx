import React from 'react'

const Inicial = () => {
  return (
    <div>Inicial</div>
  )
}

export default Inicial