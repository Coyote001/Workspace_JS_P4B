import React from 'react'

const Dpo_lgpd = () => {
  return (
    <div>Dpo_lgpd</div>
  )
}

export default Dpo_lgpd