import React from 'react'
import GerenciamentoAlunos from './components/GerenciamentoAlunos'

const App = () => {
  return (
    <div>
      <GerenciamentoAlunos/>
    </div>
  )
}

export default App