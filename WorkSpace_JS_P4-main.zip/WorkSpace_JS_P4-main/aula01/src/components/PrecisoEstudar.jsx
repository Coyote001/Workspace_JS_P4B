import React from 'react'

const PrecisoEstudar = (props) => {
  return (
    <div>
        <h1>Preciso estudar : 
            {props.nomeDaTecnologia}</h1>
    </div>
  )
}

export default PrecisoEstudar