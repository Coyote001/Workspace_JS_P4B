import React from 'react'

const Exercicio2 = () => {
  return (
    <div style={{ color: '#ff0000', backgroundColor:'#0000ff', width: '200px', textAlign: 'center'}}>
    
        Isso não é um teste
    
    </div>


  )
}

export default Exercicio2