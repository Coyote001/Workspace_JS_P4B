import React from 'react'

const Exercicio1 = () => {
  return (
    <div>
        <p>Isso é um teste</p>
        <img src="image.png" alt="" />
    </div>
  )
}

export default Exercicio1